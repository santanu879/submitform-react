import axios from 'axios';

const axiosClient = axios.create({
    baseURL: `https://localhost:44346/api/`,
    headers: {
      'Content-Type':  "application/json; charset=utf8",
      'Accept': 'application/json',
      'Access-Control-Allow-Origin':'*',
    }
  });


  
  axiosClient.interceptors.response.use(
    function (response) {
      return response;
    }, 
    function (error) {
      let res = error.response;
      if (res.status === 401) {
     
      }
      else if (res.status === 404) 
      {
        console.log('error:' ,res.status);
      }
      else{
        //window.location.href='/404';
        console.log(JSON.stringify(error.response.data?.errors));
        console.log('error:' ,error.message);
      }
      return Promise.reject(error);
    }
  );


  export default   axiosClient ;