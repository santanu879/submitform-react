
import  axiosClient  from "../axiosClient";
import resolve from '../resolve';

async function getAllCustomer(){
    return  await resolve(axiosClient.get('/Customer/GetCustomers').then(res => res.data));
}

async function getCustomerById(id){
    return  await resolve(axiosClient.get(`/Customer/${id}`).then(res => res.data));
}

async function saveCustomer (data){
    return  await resolve(axiosClient.post(`/Customer`,data).then(res => res.data));
}
const api={
    getAllCustomer,
    getCustomerById,
    saveCustomer
}

export default api