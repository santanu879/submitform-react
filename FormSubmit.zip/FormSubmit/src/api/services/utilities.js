import  axiosClient  from "../axiosClient";
import resolve from '../resolve';

async function getAllCities(){
    return  await resolve(axiosClient.get('/Utilities/GetCities').then(res => res.data));
}
async function getCityById(id){
    return  await resolve(axiosClient.get(`/Utilities/GetCity/${id}`).then(res => res.data));
}
async function getCitiesByStateCode(StateCode){    
    return  await resolve(axiosClient.get(`/Utilities/GetCityByStateCode/${StateCode}`).then(res => res.data));
}
async function getAllStates(){
    return  await resolve(axiosClient.get('/Utilities/GetStates').then(res => res.data));
}
async function getStateByStateCode(StateCode){
    return  await resolve(axiosClient.get(`/Utilities/GetState/${StateCode}`).then(res => res.data));
}
const utilitiesApi={
    getAllCities,
    getCityById,
    getCitiesByStateCode,
    getAllStates,
    getStateByStateCode
}

export default utilitiesApi;