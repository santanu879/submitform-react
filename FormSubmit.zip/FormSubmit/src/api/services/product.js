import  axiosClient  from "../axiosClient";
import resolve from '../resolve';

async function getAllCustomer(){
    return  await resolve(axiosClient.get('/Customer/GetCustomers').then(res => res.data));
}
async function getProductById(id){
    return  await resolve(axiosClient.get(`/products/${id}`).then(res => res.data));
}
const api={
    getAllProduct,
    getProductById
}

export default api