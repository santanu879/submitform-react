import react from "react";

const Dropdown = ({ text,id,value, selectvalue, options=[], onChange ,...rest}) => {
    return (
      <label>
        <select value={value} onChange={onChange} {...rest}>
          {options.map((option,key) => (
            <option key={key} value={option[id]}>{option[text]}</option>
          ))}
        </select>
      </label>
    );
  };
  const areEqual = (prevProps, nextProps) => {
    if (JSON.stringify(prevProps.options.length) !== JSON.stringify(nextProps.options.length)) {
      return false
    }
    return true
  }
export default react.memo(Dropdown);