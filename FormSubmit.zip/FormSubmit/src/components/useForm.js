import { useState } from 'react';

const useForm = (initModel, submitCallback) => {
  const [inputs, setInputs] = useState(initModel);

  const handleChange = e => {  
    e.persist();
    traverseObject(inputs,e)
    updateModel({...inputs});
  };

  const traverseObject=(obj,e)=>{
    Object.keys(obj).map(i => {
      const ctrl=obj[i];
      
      if(Array.isArray( ctrl)){
        ctrl.map(c=>{traverseObject(c,e)});
      }
      if (ctrl.name === e.target.name) {
        ctrl.value = ctrl.type === 'checkbox' ? e.target.checked : e.target.value;
        parseInput(ctrl);
        validateInput(ctrl);
        return;
      }
    });
  }

  const handleSubmit = e => {  
      e && e.preventDefault();
      if(inputs.haserror ==undefined || inputs.haserror){
      Object.keys(inputs).map(i =>{   let ctrl=inputs[i]; validateInput(ctrl)});
      
    let haserror= getErrors(inputs);
    
     haserror.some(v=> v ==true)
       ? updateModel({...inputs})
     : submitCallback('Hi')
    }
  };
 
  const traverseHaserror=(model)=>{
   return Object.keys(model).map(m=> {    
      if(!Array.isArray(model[m])){ 
        return model[m].haserror;
      }
       else{
          return  model[m].map(c=> traverseHaserror(c))
       }      
    })  
  }
 
  const getErrors=(model)=>{
    let arr=[];
    if(Array.isArray(model)){
      arr=model.map(t=>traverseHaserror(t) );      
    }
    else
       arr=traverseHaserror(model)
      
    let flatArray =flatten(arr)
   
    return flatArray;
  }
  const flatten =(arr)=> {
    return arr.reduce(function (flat, toFlatten) {
      return flat.concat(Array.isArray(toFlatten) ? flatten(toFlatten) : toFlatten);
    }, []);
  }
  const parseInput = input => input.value = input.parseFun ? input.parseFun(input.value) : input.value;

  const validateInput = input => {
    let alert = null;    
    if(Array.isArray( input)){        
      input.map(i=>{
        Object.keys(i).map(o=>{
          validateInput(i[o]);
        })

      })
       
    }
    input.validators && input.validators.forEach(v => alert = v.isValidFun && !v.isValidFun(input.value) ? v.alert : alert);
   
     input.alert = alert ;
     input.haserror= alert ==null ? false : true;
     
  }
  const validateSpecificTag=(tag)=>{    
     validateInput(inputs[tag]);     
     let haserror=getErrors(inputs[tag]);
     if(haserror) updateModel(inputs);
    return haserror.some(e => e ==true);;
  }
  const updateModel=(model)=>{
    setInputs({...model});
  }
  return [inputs, handleChange, handleSubmit,updateModel,validateSpecificTag]
};



export default useForm;