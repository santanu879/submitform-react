import { parseOnlyLetterAndSpace, parseLength,parseOnlyNumber } from '../Input/inputParser';
import { checkAtLeastLength,checkIsfilled,checkEmailPattern,isSelect } from '../Input/inputValidator';




const registrationModel =  {    
FirstName:
    {    
    name: 'FirstName',
    label: 'First Name',
    type: 'text',
    isRequired:true,
    parseFun: parseOnlyLetterAndSpace,
    validators: [{
        id: 'name-length',
        isValidFun: expression => checkAtLeastLength(expression, 3),
        alert: 'FirstName is too short'
    },
    {
        id: 'name-length',
        isValidFun: checkIsfilled,
        alert: 'First Name is Empty'
    }
]
},
LastName:
    {    
    name: 'LastName',
    label: 'Last Name',
    type: 'text',
    parseFun: parseOnlyLetterAndSpace,
    isRequired:true,
    validators: [{
        id: 'name-length',
        isValidFun: expression => checkAtLeastLength(expression, 3),
        alert: 'LastName is too short'
    },
    {
        id: 'name-length',
        isValidFun: checkIsfilled,
        alert: 'LastName is Empty'
    }
]
},
Email:
{
    name: 'Email',
    label: 'Email',
    type: 'text',
    isRequired:true,
    validators: [{
        id: 'mail-pattern',
        isValidFun: checkEmailPattern,
        alert: 'Email is not valid'
    }, {
        id: 'email-required',
        isValidFun: checkIsfilled,
        alert: 'Email is empty'
    }]
},
Address:
    {    
    name: 'Address',
    label: 'Address',
    type: 'text',
    isRequired:true,
    parseFun: parseOnlyLetterAndSpace,
    validators: [{
        id: 'address-length',
        isValidFun: expression => checkAtLeastLength(expression, 5),
        alert: 'Address is too short'
    }
]
}
,
City:
    {    
    name: 'City',
    label: 'City',
    type: 'text',
    isRequired:true,
    options: [],
    validators: [{
        id: 'City-length',
        isValidFun: isSelect,
        alert: 'City is requried'
    }    
]
},
Child:[]
};

const childrenModel={
cName:
    {    
    name: 'Name',
    label: 'Name',
    type: 'text',
    parseFun: parseOnlyLetterAndSpace,
    validators: [{
        id: 'name-length',
        isValidFun: expression => checkAtLeastLength(expression, 3),
        alert: 'FirstName is too short'
    },
    {
        id: 'name-length',
        isValidFun: checkIsfilled,
        alert: 'First Name is Empty'
    }
]
},
cAge:
{
    name: 'Age',
    label: 'Age',
    type: 'text',
    value:'',
    parseFun: parseOnlyNumber,
    isRequired:true,
    validators: [{
        id: 'age-length',
        isValidFun: checkIsfilled,
        alert: 'Age is Empty'
    }]
},
education:[]
}

const educationModel={
    school:
        {    
        name: 'SchoolName',
        label: 'SchoolName',
        type: 'text',
        parseFun: parseOnlyLetterAndSpace,
        validators: [{
            id: 'name-length',
            isValidFun: expression => checkAtLeastLength(expression, 3),
            alert: 'School is too short'
        },
        {
            id: 'name-length',
            isValidFun: checkIsfilled,
            alert: 'School Name is Empty'
        }
    ]
    }
}
export {registrationModel,childrenModel,educationModel};
