import { useEffect, useState } from "react";
import api from "../../api/services/customer";
import useForm from "../useForm";
import {registrationModel,childrenModel,educationModel} from '../esystems/registrationModel';
//import childrenModel from '../esystems/registrationModel';
import TextInput from '../Input/TextInput';
import CheckboxInput from '../Input/checkboxInput';
import SelectInput from '../Input/SelectInput';
import utilitiesApi from '../../api/services/utilities';
import { useMemo } from "react";

const Esystems=()=>{
    
   

    const submitCallback = (model) => 
    {
        let data=
        {
                CustomerId:0,
                FirstName:inputs['FirstName'].value,
                LastName:inputs['LastName'].value,
                Phone: '',
                Email: inputs['Email'].value,
                Street: inputs['Address'].value,
                City:0,
                State:0,
                ZipCode:'',
                DateOfBirth:'2022-06-01T10:02:04.518Z'
        }
        debugger;
        alert('Call calback..');
       // api.saveCustomer(data);
    }
    const [inputs, setInputs, setSubmit,updateModel,validateSpecificTag] = useForm(registrationModel, submitCallback);
    const [cities,setCities] =useState([]);  

    useEffect(()=>{
        getAllCities();
    },[])
    const Components = { TextInput};
    const capitalize = expression => expression.charAt(0).toUpperCase() + expression.slice(1);
    const renderFirstName=()=> {        
         const input=inputs.FirstName;
        const Component = Components[capitalize(input.type) + 'Input'];
        return <Component key={input.name} setInputs={setInputs} {...input} />;
      }

      const getAllCities= async ()=>{
        const cities= await utilitiesApi.getAllCities();
        inputs.City.options=cities.data;
        inputs.City.options.unshift({name:'Select',id:0});
        
        setCities(cities.data);
      }
    
    const addChild=()=>{
        const count=inputs.Child.length;
        let model={...inputs};
        let cModel={...childrenModel};
        let eduModel={...educationModel};
        cModel.cName={...cModel.cName,['name']:`name_${count}`}
        cModel.cAge={...cModel.cAge,['name']:`age_${count}`}
              
        eduModel.school={...eduModel.school,['name']:`SchoolName_0_${count}`}
        
        cModel.education=[...cModel.education,eduModel];

        let regChild=[...model.Child,cModel];
      
        
        model.Child=regChild;  
       
        if(count==0)
        updateModel(model);
        else
         if(!validateSpecificTag('Child'))
         {
            updateModel(model);
         }
    }
    const removeChild=(index)=>{
        console.log(index);
        let model={...inputs};
        let regChild=[...model.Child]
        regChild.splice(index, 1)
        
        
        model.Child=regChild;  
        updateModel(model);
    }
    const addSchool=(index)=>{        
        let eduModel={...educationModel};
        let model={...inputs};
        debugger;
        const count=model.Child[index].education.length;
        
        eduModel.school={...eduModel.school,['name']:`SchoolName_${index}_${count+1}`};

        let regChild=[...model.Child[index].education,eduModel];     
        
        model.Child[index].education=regChild;  

        updateModel(model);
    }
    return(
        <form
          id='registrationForm'
          method='POST'
          className="row g-3 pt-2"
         // onSubmit={handleSubmit}
        >

                <div className="col-md-4">
                    <TextInput  setInputs={setInputs} {...inputs.FirstName}/>
                </div>
                <div className="col-md-4">
                     <TextInput  setInputs={setInputs} {...inputs.LastName}/>
                </div>
                <div className="col-md-4">
                    <TextInput  setInputs={setInputs} {...inputs.Address}/>
                </div>
                <div className="col-md-4">
                    <TextInput  setInputs={setInputs}  {...inputs.Email}/>
                </div>
                <div className="col-md-4">
                    <SelectInput  setInputs={setInputs} textField='name' idField='id' {...inputs.City}/>
                </div>
             <div className="col-md-12">
                <button type="button" className="btn btn-success" onClick={addChild}>Add Child Details</button>
             </div>
             {inputs.Child && inputs.Child.map((c,index) => 
            <div className="container" key={index}>
                <div className="row">
                    <div className="col-md-4">
                    <TextInput  setInputs={setInputs} {...c.cName}/>
                    </div>
                    <div className="col-md-4">
                        <TextInput setInputs={setInputs} {...c.cAge} maxLength="2"/>
                    </div>
                    <div className="col-md-4 pt-4">                        
                        <button type="button" className="btn-close" aria-label="Close" onClick={()=>removeChild(index)}></button>
                    </div>
                { c.education && c.education.map((c,eindex) =>
                     
                    <div className="row" key={eindex}>
                        {(eindex==0) &&
                               <>
                                   <div className="col-md-4">
                                       <button  type="button" className="btn btn-success" onClick={()=>addSchool(index)}>Add School</button>
                                   </div>
                                   <div className="col-md-8">
                                   </div>
                               </>
                        }
                             <div className="col-md-4">
                                 <TextInput setInputs={setInputs} {...c.school} />
                             </div>
                            
                    </div> 
                    )}
                   
                </div>               
            </div>
            )
        }
         
        <div className="col-12">
           <button type="submit" onClick={setSubmit} className="btn btn-primary">Submit</button>
          
        </div>
     </form>
    )
}

export default Esystems;