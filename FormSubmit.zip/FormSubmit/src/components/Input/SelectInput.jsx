import React from 'react';
import ValidationAlert from './ValidationAlert';

const SelectInput=({textField,idField, name, label,  value, options, alert,setInputs ,...rest})=> {
       return (
        <div>
            <label htmlFor={name} className="form-label">{label} 
             {rest.isRequired && <span style={{color:'red'}}>*</span>}</label>
            <select value={value} className="form-select"  name={name} onChange={setInputs} {...rest}>
                {options.map((option, key) => (
                    <option key={key} value={option[idField]}>{option[textField]}</option>
                ))}
            </select>
            
           <ValidationAlert content={alert} />
           
        </div>
    )
}

export default SelectInput;