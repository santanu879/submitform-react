import * as React from 'react';
import ValidationAlert from '../../components/Input/ValidationAlert';

function TextInput({ name, label, type, value, alert, setInputs,...rest }) {
    return (
        <div>
            <label htmlFor={name} className="form-label">{label}
                 {rest.isRequired && <span style={{color:'red'}}>*</span>}
            </label>
            <input id={name} name={name} type={type} value={value || ""} onChange={setInputs}
            // className={"uk-input" + (alert ? ' uk-form-danger' : '')}
            className="form-control" {...rest}
             />
             
            <ValidationAlert content={alert} />
        </div>
    )
}

export default TextInput;