import React from 'react';

const ValidationAlert = ({ content }) => {
    return <div style={{color:'red'}}>{content}</div>
}

export default ValidationAlert;