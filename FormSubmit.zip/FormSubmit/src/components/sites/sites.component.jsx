import React, { Component } from "react";
import { Fragment } from "react";
import usaSiteimageMap from './usaSiteimageMap.jpg';
import areas from './area.js';
export default class Sites extends Component 
{
    consoleMessage(State_Code,State_Name,e){
        e.preventDefault();
    console.log( State_Code,State_Name);
  }
  render(){
    return (
        <Fragment>
            <img src={usaSiteimageMap} alt="Workplace"  useMap="#workmap" width="500" height="425"/>

            <map name="workmap" style={{cursor:"pointer"}}>
             { 
                areas.map((area, index) => {
                  return( <area shape='poly' key={index} onClick={this.consoleMessage.bind(this,area.v1, area.v2)} alt={area.alt} coords={area.coords} /> )
                })
             }
          </map>
        </Fragment>
    )
  }
}
