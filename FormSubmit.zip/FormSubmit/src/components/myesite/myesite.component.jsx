import React,{ useCallback, useEffect, useState,useMemo } from "react";
import Dropdown from "../controls/dropdown";
import api from '../../api/services/customer';

import utilitiesApi from '../../api/services/utilities';

const MyEsite=()=>{
const [product,setProduct] =useState([]);
const [cities,setCities] =useState([]);
const [states,setStates] =useState([]);
const [city,setCity] =useState([]);
const [state,setState] =useState([]);


const[arr,setarr]=useState([1,29,20,3,8]);
const memiozed=useMemo(()=>getLargestNumber(),[arr]);

function getLargestNumber(){
  console.log('getLargestNumber');
  return Math.max(...arr);
}

function changeArray(e)
{
  setarr([46,90,67,8]);
}

useEffect(()=>{
  // getProducts();
  // getAllCities();
  // getAllStates();
},[])

const getProducts= async ()=>{
  const product= await api.getAllCustomer();
  setProduct(product.data);
}
const getAllCities= async ()=>{
  const cities= await utilitiesApi.getAllCities();
  setCities(cities.data);
}
const getAllStates= async ()=>{
  const states= await utilitiesApi.getAllStates();
  setStates(states.data);
}
const getCitiesByStateCode= async (stateCode)=>{
  const cities= await utilitiesApi.getCitiesByStateCode(stateCode);  
  setCities(cities.data);
}

const onChangeCity =(event) => {
  setCity(event.target.value);
};
const onChangeState =useCallback( (event) => {
  setState(event.target.value);
  getCitiesByStateCode(event.target.value);
},[setStates]);
const onChangeProduct= (id)=>{
    
   const getProductsById= async (id)=>{
    const product= await api.getCustomerById(id);
    if( product.data !=null)
      setProduct([product.data]);
    }
    if(id!== '')
      getProductsById(id);
}
    return(
        <>
        <h1>{memiozed}</h1>
         <h1>My Esite.</h1>
         <br/>
         City :
         <Dropdown style={{width:'600px'}} options={cities} value={city} text='name' id='id' onChange={onChangeCity} className='Primary'/>
         <br/>
         <br/>
         <br/>
         State :
         <Dropdown options={states} value={state} text='name' id='id' onChange={onChangeState} className='Primary'/>
         <br/>
         <br/>
         <input type='text' onChange={(e)=>{
            onChangeProduct(e.target.value);
         }}></input>
         <div className="container">
         {
            product.map((item)=>(
                <p key={item.customerId}>{item.firstName}</p>
             ))
         }
         </div>
         <p  onClick={changeArray} className="btn btn-primary">Change Array</p>
        </>
    )
}

export default React.memo(MyEsite);