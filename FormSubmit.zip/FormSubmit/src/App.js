import { Routes, Route } from 'react-router-dom';
import Navigation from './route/navegation/navegation.component';
import MyEsite from './components/myesite/myesite.component';
import Esystems from './components/esystems/esystems.component';
import Sites from './components/sites/sites.component';
import { Button } from "react-bootstrap";

import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
     <>
    <Routes>
      <Route path='/' element={<Navigation/>}>
         <Route path='/MyEsite' element={<MyEsite/>}></Route>
         <Route path='/eSystems' element={<Esystems/>}></Route>
         <Route path='/Sites' element={<Sites/>}></Route>
         <Route path='*' element={<h1>404</h1>}></Route>
      </Route>
    </Routes>

    </>
    
  );
}

export default App;


// Notes https://formik.org/  reactWindow
