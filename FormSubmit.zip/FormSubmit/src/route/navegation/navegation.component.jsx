import React,{Fragment} from "react";
import { Outlet } from "react-router-dom";

import Header from "../header/header.component";
import Footer from "../footer/footer.component";

const Navigation=()=>{
    return(
        <Fragment>
            <Header/>
            
            {/* render body */}
            <div className="container" style={{paddingTop:'50px'}}>
               <Outlet/>  
            </div>
               
            
            <Footer/>
        </Fragment>
    )
}

export default Navigation;