import { Outlet, Link } from "react-router-dom";

//import './navigation.styles.scss';
const Header = () => {
    return (
        <div className="navbar navbar-expand-md navbar-dark fixed-top navbar-dark bg-primary">
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
                <Link className="nav-link" to='/MyEsite'>my eSite </Link>
                <Link className="nav-link" to='/eSystems'>eSystems </Link>
                <Link className="nav-link" to='/auth'>Reports </Link>
                <Link className="nav-link" to='/Sites'>Sites </Link>
                <Link className="nav-link" to='/auth'>Documents </Link>
                <Link className="nav-link" to='/auth'>Search </Link>
                </ul>
            </div>
        </div>
    )
}

export default Header;